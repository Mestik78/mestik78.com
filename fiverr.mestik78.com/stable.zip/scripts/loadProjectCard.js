function loadName(project, projectFrame) {
    let storeGameTitle = projectFrame.getElementsByClassName("storeGameTitle")[0]
    storeGameTitle.innerText = project.name.toUpperCase()
}

function loadInfo(project, projectFrame) {
    let infoContainer = projectFrame.getElementsByClassName("infoContainer")[0]
    
    if (!project.info.gamepasses) {
        infoContainer.getElementsByClassName("gamepasses")[0].className += " hide"
    }
    if (project.info.type != "asset") {
        infoContainer.getElementsByClassName("asset")[0].className += " hide"
    }
    if (!project.info.original) {
        infoContainer.getElementsByClassName("original")[0].className += " hide"
    }

    infoContainer.className = "infoContainer"
}

function loadLink(project, projectFrame) {
    let a = projectFrame.getElementsByTagName("a")[0]
    a.href = "../project?project=" + project.name
}

function loadImage(project, projectFrame) {
    let imageContainer = projectFrame.getElementsByClassName("imageContainer")[0]
    let image = imageContainer.getElementsByTagName("img")[0]
    image.src = project.image.main
}


async function loadproject(project, projectFrame) {
    loadName(project, projectFrame)
    loadInfo(project, projectFrame)
    loadLink(project, projectFrame)
    loadImage(project, projectFrame)
}


async function loadProjectCard(project, projectFrame) {
    let className = project.className
    
    project.className += " hide"
    await loadproject(project, projectFrame)
    project.className = className
}