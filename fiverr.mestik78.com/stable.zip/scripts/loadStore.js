function readStringFromFileAtPath(pathOfFileToReadFrom)
{
    var request = new XMLHttpRequest();
    request.open("GET", pathOfFileToReadFrom, false);
    request.send(null);
    var returnValue = request.responseText;

    return returnValue;
}

function loadProject(project, frame) {
    let newProject = document.createElement("div")
    newProject.innerHTML = readStringFromFileAtPath("../projectCard?project=" + project.name);
    newProject.className = "projectFrame"
    frame.appendChild(newProject)

    loadProjectCard(project, newProject)
    /*
    let newProject = document.createElement("iframe")
    newProject.src = "../projectCard?project=" + project.name
    newProject.className = "projectFrame"
    frame.appendChild(newProject)
    */
}

function deleteProjects(projectsFrame) {
    projectsFrame.innerHTML = ""
}

async function loadStore() {
    if(typeof ProjectsJson == "undefined"){
        setTimeout(loadStore, 10);
        return
    }
    
    const gamesFrame = document.getElementById("gamesFrame")
    const assetsFrame = document.getElementById("assetsFrame")

    deleteProjects(gamesFrame)
    deleteProjects(assetsFrame)
    for ([key, project] of Object.entries(ProjectsJson)) {
        if (project.info.type == "game") {
            loadProject(project, gamesFrame)
        }
        if (project.info.type == "asset") {
            loadProject(project, assetsFrame)
        }
    }
}
loadStore()


var ProjectsJson
fetch("./data/robloxProjects.json")
    .then(response => response.json())
    .then(json => {
        ProjectsJson = json
    })